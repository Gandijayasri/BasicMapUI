//
//  lslandimg.swift
//  SwiftUI1
//
//  Created by jayasri on 19/12/22.
//

import SwiftUI

struct CircleImage: View {
    var body: some View {
        Image("Island")
            .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 200)
                        .border(Color.pink)
                        .clipped()
            .clipShape(Circle())
                    .overlay {
                Circle().stroke(.gray, lineWidth: 4)
            }
    }
}

struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage()
    }
}
