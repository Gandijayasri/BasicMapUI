//
//  SwiftUI1App.swift
//  SwiftUI1
//
//  Created by jayasri on 19/12/22.
//

import SwiftUI

@main
struct SwiftUI1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
